# Portfolio Review Lab - start here

You are a portfolio leader at **Northstar Digital**. Every Monday you review your accounts and decide
which ones need your attention this week. Today that judgement lives in your head. In this lab you
will write it down, turn it into a Claude skill, test it, fix it, and schedule it.

## What is in this folder

- `Account_Packs/` - one folder per account, each with the same six files:
  - `Weekly_Status_Report.docx` - the account manager's report, with RAG status
  - `Financials.xlsx` - monthly revenue, cost and gross margin, plus contract details
  - `Escalations_Log.xlsx` - client escalations this year
  - `CSAT_Pulse.csv` - monthly client satisfaction scores, by respondent
  - `Team_Roster.xlsx` - who works on the account
  - `Meeting_Notes.md` - recent governance and internal notes
- `Leader_Brief/Lakshmi_Rao_Persona.md` - use this only if you do not run a portfolio yourself
- `Portfolio_Outputs/` - save everything you produce here, using the exact file names in the guide

## Accounts in this week's review

1. Kestrel Logistics
2. Alder Health
3. Solace Retail
4. Harbor Mutual Insurance

Click **Evaluate** at any time to see your progress and feedback.
