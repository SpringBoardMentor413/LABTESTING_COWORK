# Leader brief - Lakshmi Rao, VP Delivery, Northstar Digital

Use this brief only if you do not run an account portfolio yourself. When Claude interviews you,
answer as Lakshmi, in your own words. Stick to what she believes below. Do not add rules she does not have.

## About Lakshmi
- 19 years in IT services; runs a portfolio of 4 accounts worth about INR 85 crore a year.
- Reviews every account on Monday morning before her 10:00 call with the CEO.
- Has about 15 minutes per account.

## How Lakshmi judges an account today
- **Margin:** "I start to worry when the quarter's gross margin falls under 25%, or drops more than 3 points from the previous quarter."
- **Escalations:** "Two or more open escalations, or any open Sev1, and I want a call with the account manager."
- **Client satisfaction:** "If the average CSAT goes under 7, or falls by a full point over three months, something is wrong."
- **RAG:** "Any Red on the status report, or two Ambers, and I look closer."
- **People and key-person risk:** "If the account manager flags a single point of failure in the status report, I want to know. I trust my AMs on people matters, they know their teams."
- **Verdicts:** "Two or more of those and the account is At risk. One and it's on Watch. None and it's Healthy."
- **What she wants on Monday:** "One table: account, verdict, the top reason, and where the evidence is. Worst first. Then a line on what I should do this week."
