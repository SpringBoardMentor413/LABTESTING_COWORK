# Harbor Mutual Insurance - governance notes

## Monthly governance review - 06-Nov-2026
Attendees: D. Menon (VP IT), L. Pereira (Claims Head); Vikram Sethi, Prakash Nair (Northstar)

- Release 4.2 walkthrough; Pereira happy with the claims rules update.
- Menon asked for the Q1 roadmap draft by mid-Dec.
- Rules-engine CR backlog: 6 CRs queued; all currently with Ravi.
- Menon mentioned that the new CIO (A. Fernandes, joined in October) has asked for a vendor landscape review of all core-systems partners before the January renewals.
- AOB: next review 04-Dec.

## Internal account sync - 10-Nov-2026
- Ravi's resignation: handled with HR, counter-offer declined. Keeping it out of the client status report until a backfill is identified.
- Release 4.3 planning to start after Ravi hands over the CR backlog.
