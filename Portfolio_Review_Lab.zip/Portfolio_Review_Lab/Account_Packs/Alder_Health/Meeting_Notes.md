# Alder Health - governance notes

## Monthly governance review - 21-Oct-2026
Attendees: Dr. K. Rao (CMIO), P. Thomas (IT Director), M. George (Service Desk Lead); Neha Kapoor, Suresh Iyengar (Northstar)

- RCA for the 28-Sep outage presented; Dr. Rao accepted it and thanked the team for transparency.
- 7 of 8 preventive actions done; last one (failover drill) scheduled 25-Nov.
- Thomas asked for a Phase 2 estimate for lab-results integration by end-Nov.

## Internal account sync - 07-Nov-2026
- Margin back to ~28% in October now that shadow resources have rolled off as planned.
- Delivery RAG must stay Red until 08-Dec under the Sev1 governance policy, even though the issue is closed.
