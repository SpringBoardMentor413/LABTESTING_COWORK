# Kestrel Logistics - governance notes

## Monthly governance review - 04-Nov-2026
Attendees: S. Pillai (Ops Director), R. Bose (IT Manager), T. Nair (Program Lead); Arjun Mehta, Karan Malhotra (Northstar)

- Pillai opened with the Sep sync outage; wants a written stability plan by end-Nov and service credits discussed.
- Bose raised two failed route-planner releases in October; asked for release gating.
- Nair: CRs being delivered without formal sign-off is creating rework on their side.
- Northstar to propose change orders for the CR backlog; client not yet agreed to pay for all of them.

## Internal account sync - 10-Nov-2026
- Margin has slid every month since July; CR absorption is the main driver.
- Agreed to escalate change-order approval to the portfolio head this week.
