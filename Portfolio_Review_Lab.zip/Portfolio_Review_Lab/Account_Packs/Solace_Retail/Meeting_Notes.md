# Solace Retail - governance notes

## Quarterly business review - 14-Oct-2026
Attendees: A. Kulkarni (CTO), R. Shetty (E-commerce Head); Rahul Desai, Gita Nambiar (Northstar)

- Renewal signed in the meeting: 3 years, end date 31-Oct-2029.
- Kulkarni praised festive-season readiness; wants an AI-led merchandising pilot proposal in Q1.

## Internal account sync - 06-Nov-2026
- Loyalty-engine KT: Swati now handling 60% of tickets; target fully independent by mid-Dec.
- No concerns raised.
